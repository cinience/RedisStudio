RedisStudio
===========
# 地址
-
  [github] https://github.com/cinience/RedisStudio
  
# 介绍
- 
  Redis Studio 是Redis桌面客户端，支持Windows操作系统
- 
  界面基于duilib开发，内核客户端采用 MSOPEN hiredis

# 计划
1. 
  完善Windows各版本兼容性
1. 
  完善UI设计
1. 
  开发管理功能（lua支持）
1. 
  国际化支持

 
# 期待
-  
  如果你喜欢Redis Studio 并想加入开发设计Redis Studio，请联系我！
- 
  如果你对Redis Studio 有任何建议，请在Issues中提出来。
